import {
    fetchPixabay
} from "../src/client/js/getPixabay"

describe("Testing fetchPixabay()", () => {
    test("TEST: fetchPixabay()", () => {
        fetchPixabay();
    })
})