import {
    handleSubmit
} from "../src/client/js/submitForm"

describe("Testing handleSubmit()", () => {
    test("TEST: handleSubmit()", () => {
        handleSubmit();
    })
})